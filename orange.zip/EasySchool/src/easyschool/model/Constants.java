package easyschool.model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Matheus
 */
public class Constants {
    public final static String CALCULO_1 = "Calculo 1";
    public final static String CALCULO_2 = "Calculo 2";
    public final static String CALCULO_3 = "Calculo 3";
    public final static String ALGEBRA = "ALGEBRA";
    public final static String CIRCUITOS = "Circuitos Elétricos";
    public final static String FISICA_1 = "Física 1";
    public final static String FISICA_2 = "Fíaica 2";
    public final static String FISICA_3 = "Física 3";
    public final static String ALGORITMO_1 = "Algoritmos 1";
    public final static String ALGORITMO_2 = "Algoritmos 2";
    public final static String ALGORITMO_3 = "Algoritmos 3";
    public final static String CALCULO_NUMERICO = "Cálculo numérico";
    public final static String ORIENTACAO_OBJETO = "Orientação a objeto";
    public final static String METODOLOGIA = "Metodologia";
    
  
       
}
