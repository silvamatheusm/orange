/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package easyschool;

import easyschool.view.LoginView;

/**
 *
 * @author aluno
 */
public class EasySchool {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginView login = new LoginView();
        login.setVisible(true);
        // TODO code application logic here
    }
    
}
